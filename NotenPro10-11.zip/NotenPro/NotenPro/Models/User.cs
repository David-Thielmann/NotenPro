namespace HTLKrems.GradeManagement.Models
{
    // Partial placeholder to unify type across project.
    public partial class User { }
}
